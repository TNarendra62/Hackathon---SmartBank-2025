from pydantic import BaseModel
from typing import Optional

class UserCreate(BaseModel):
    firstname: str
    lastname: str
    age: int
    dob: str
    location: str

class KYCUpdate(BaseModel):
    status: Optional[str] = "pending"  # pending / verified / rejected


# -----------------------------
# class LoanApplication(BaseModel):
#     customer_id: str
#     loan_type: str
#     amount: float
#     tenure: int  # months
#     interest_rate: Optional[float] = 0.08  # default 8% annual

# class LoanStatusUpdate(BaseModel):
#     status: str  # "approved" or "rejected"