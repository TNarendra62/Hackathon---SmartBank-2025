users = {}       # user_id -> user info
kyc_files = {}   # user_id -> file info

# -----------------------------
# NEW storage for Loan EMI
# -----------------------------
#loans = {} 