from fastapi import FastAPI, UploadFile, File, HTTPException
from models import UserCreate, KYCUpdate
from storage import users, kyc_files
from models import  LoanApplication,LoanStatusUpdate
from storage import loans
import uuid

app = FastAPI()  

@app.post("/register")
def register_user(user: UserCreate):
    user_id = str(uuid.uuid4())
    users[user_id] = user.dict()
    users[user_id]["kyc_status"] = "pending"
    return {"user_id": user_id, "message": "User registered successfully", "user_data": users[user_id]}

@app.post("/upload_kyc/{user_id}")
def upload_kyc(user_id: str, file: UploadFile = File(...)):
    if user_id not in users:
        raise HTTPException(status_code=404, detail="User not found")
    if file.content_type != "application/pdf":
        raise HTTPException(status_code=400, detail="Only PDF files allowed")
    kyc_files[user_id] = {"filename": file.filename, "content_type": file.content_type}
    return {"message": f"KYC uploaded for user {user_id}"}

@app.put("/verify_kyc/{user_id}")
def verify_kyc(user_id: str, kyc_update: KYCUpdate):
    if user_id not in users:
        raise HTTPException(status_code=404, detail="User not found")
    users[user_id]["kyc_status"] = kyc_update.status
    return {"message": f"KYC status updated to {kyc_update.status} for user {user_id}"}


@app.get("/")
def root():
    return {"message": "SmartBank API is running! Successfully deployed."}


# # ------  -here for the EMI calculation
def calculate_emi(principal, annual_rate, tenure_months):
    r = annual_rate / 12  # monthly interest rate
    n = tenure_months
    emi = (principal * r * (1 + r)**n) / ((1 + r)**n - 1)
    return round(emi, 2)


# # Loan Endpoints
# # -----------------------------
@app.post("/apply_loan")
def apply_loan(loan: LoanApplication):
    loan_id = str(uuid.uuid4())
    emi = calculate_emi(loan.amount, loan.interest_rate, loan.tenure)
    loans[loan_id] = loan.dict()
    loans[loan_id]["emi"] = emi
    loans[loan_id]["status"] = "pending"
    return {"loan_id": loan_id, "emi": emi, "message": "Loan application submitted", "loan_data": loans[loan_id]}

@app.get("/calculate_emi/{loan_id}")
def get_emi(loan_id: str):
    if loan_id not in loans:
        raise HTTPException(status_code=404, detail="Loan not found")
    return {"loan_id": loan_id, "emi": loans[loan_id]["emi"]}

@app.put("/admin/approve_loan/{loan_id}")
def approve_loan(loan_id: str, status_update: LoanStatusUpdate):
    if loan_id not in loans:
        raise HTTPException(status_code=404, detail="Loan not found")
    loans[loan_id]["status"] = status_update.status
    return {"message": f"Loan {loan_id} status updated to {status_update.status}"}

@app.put("/admin/reject_loan/{loan_id}")
def reject_loan(loan_id: str, status_update: LoanStatusUpdate):
    if loan_id not in loans:
        raise HTTPException(status_code=404, detail="Loan not found")
    loans[loan_id]["status"] = status_update.status
    return {"message": f"Loan {loan_id} status updated to {status_update.status}"}

@app.get("/loans")
def get_all_loans():
    return loans
